// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2021-0094
// CVE: CVE-2021-45694
// CWE: N/A
// Crate: rdiff
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/rdiff
// Extraction Method: repo_search
// GitHub Repo: dyule/rdiff
// Commit: 5089484
// File: src/hashing.rs


Ok(BlockHashes {
             hashes,
             block_size,
            file_size
         })
     }