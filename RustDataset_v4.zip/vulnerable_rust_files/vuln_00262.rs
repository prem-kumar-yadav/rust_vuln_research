// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2021-0150
// CVE: N/A
// CWE: N/A
// Crate: ncollide3d
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/ncollide3d
// Extraction Method: repo_search
// GitHub Repo: dimforge/ncollide
// Commit: e584dbe
// File: src/pipeline/narrow_phase/contact_generator/ball_convex_polyhedron_manifold_generator.rs


return true;
                 }
 
                depth = N::zero();
                 normal = -cp2.feature_normal(f2);
             }