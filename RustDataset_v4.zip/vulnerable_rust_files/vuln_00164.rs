// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2021-0002
// CVE: N/A
// CWE: N/A
// Crate: interfaces2
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/interfaces2
// Extraction Method: repo_search
// GitHub Repo: aep/interfaces-rs
// Commit: 66aa4c2
// File: examples/ifconfig-simple.rs


use std::iter;
 use std::net;
 
use interfaces::{Interface, Kind, flags};

 
 // Flag mappings that ifconfig uses, in order.
 const NAME_MAPPINGS: &'static [(flags::InterfaceFlags, &'static str)] = &[
    (flags::IFF_UP, "UP"),
    (flags::IFF_LOOPBACK, "LOOPBACK"),
    (flags::IFF_BROADCAST, "BROADCAST"),
     // SMART?
    (flags::IFF_RUNNING, "RUNNING"),
     // SIMPLEX?
    (flags::IFF_MULTICAST, "MULTICAST"),
 ];
 

 fn main() {
     let mut ifs = Interface::get_all().expect("could not get interfaces");
     ifs.sort_by(|a, b| a.name.cmp(&b.name));
 
     // Find the maximum alignment for our interface names.
    let max_align = ifs.iter()
        .map(|i| i.name.len() + 2)
        .max()
        .unwrap();
 
    let full_align = iter::repeat(' ')
        .take(max_align)
        .collect::<String>();
 
     for i in ifs.iter() {
         let name_align = iter::repeat(' ')
         // Build the first line by printing the interface flags.
         let first_line = {
             let mut buf = String::new();
            buf.push_str(&*format!(
                "flags={} <",
                i.flags.bits()
            ));
 
             let mut flag_strs = vec![];
             for &(f, s) in NAME_MAPPINGS.iter() {
             }
 
             buf.push_str(&*flag_strs.join(","));
            buf.push_str(&*format!(
                "> mtu {}",
                i.get_mtu().unwrap_or(0)
            ));
 
             buf
         };
 
         println!("{}: {}{}", i.name, name_align, first_line);
 
        if i.flags.contains(flags::IFF_LOOPBACK) {
             println!("{}loop (Local Loopback)", full_align);
         } else {
             if let Ok(addr) = i.hardware_addr() {
 
 fn format_addr(addr: &net::SocketAddr) -> String {
     match addr {
        &net::SocketAddr::V4(ref a) => {
            format!("{}", a.ip())
        },
        &net::SocketAddr::V6(ref a) => {
            format!("{}", a.ip())
        },
     }
 }