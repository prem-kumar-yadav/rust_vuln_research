// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2020-0144
// CVE: N/A
// CWE: N/A
// Crate: lzw
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/lzw
// Extraction Method: repo_search
// GitHub Repo: nwin/lzw
// Commit: 430c6ba
// File: src/lib.rs


LsbReader,
     LsbWriter,
     MsbReader,
    MsbWriter
 };