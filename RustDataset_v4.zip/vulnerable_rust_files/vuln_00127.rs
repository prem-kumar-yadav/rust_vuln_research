// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2020-0115
// CVE: CVE-2020-36435
// CWE: N/A
// Crate: ruspiro-singleton
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/ruspiro-singleton
// Extraction Method: repo_search
// GitHub Repo: RusPiRo/ruspiro-singleton
// Commit: c8e06d2
// File: src/lib.rs


**********************************************************************************************************************/
 #![doc(html_root_url = "https://docs.rs/ruspiro-singleton/||VERSION||")]
 #![no_std]
#![feature(const_fn)]
 
 //! # Singleton pattern implementation
 //!