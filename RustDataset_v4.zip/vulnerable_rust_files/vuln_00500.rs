// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2025-0024
// CVE: CVE-2025-4574
// CWE: N/A
// Crate: crossbeam-channel
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/crossbeam-channel
// Extraction Method: commit_diff
// GitHub Repo: crossbeam-rs/crossbeam
// Commit: 1187
// File: no_atomic.rs


"riscv32gc-unknown-linux-musl",
     "riscv32i-unknown-none-elf",
     "riscv32imac-unknown-none-elf",
    "riscv32imc-esp-espidf",
     "riscv32imc-unknown-none-elf",
     "thumbv4t-none-eabi",
     "thumbv6m-none-eabi",