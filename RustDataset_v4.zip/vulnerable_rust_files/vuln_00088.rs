// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2020-0056
// CVE: N/A
// CWE: N/A
// Crate: stdweb
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/stdweb
// Extraction Method: repo_search
// GitHub Repo: koute/stdweb
// Commit: 6d425bc
// File: src/lib.rs


UnloadEvent,
             BeforeUnloadEvent,
 
             EventPhase
         };