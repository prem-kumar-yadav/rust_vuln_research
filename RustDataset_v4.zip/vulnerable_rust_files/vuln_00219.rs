// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2021-0089
// CVE: CVE-2021-45687
// CWE: N/A
// Crate: raw-cpuid
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/raw-cpuid
// Extraction Method: repo_search
// GitHub Repo: gz/rust-cpuid
// Commit: 21c7205
// File: src/extended.rs


}
 }
 
/// Extended Feature Identification 2 (LEAF=0x8000_0021).
 ///
 /// # Platforms
 /// ✅ AMD ❌ Intel
     }
 }
 
/// Extended Feature Identification 2 (LEAF=0x8000_0021).
 ///
 /// # Platforms
 /// ✅ AMD ❌ Intel