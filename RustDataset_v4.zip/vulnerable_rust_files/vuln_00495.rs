// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2025-0019
// CVE: N/A
// CWE: N/A
// Crate: array-init-cursor
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/array-init-cursor
// Extraction Method: repo_search
// GitHub Repo: planus-org/planus
// Commit: 3eb8cdc
// File: crates/planus-codegen/src/rust/mod.rs


parent_info.ref_name,
                     name
                 );
                can_do_infallible_conversion = false;
             }
             ResolvedType::Bool => {
                 owned_type = "bool".to_string();