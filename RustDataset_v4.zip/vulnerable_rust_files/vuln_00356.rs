// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2023-0049
// CVE: N/A
// CWE: N/A
// Crate: tui
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/tui
// Extraction Method: repo_search
// GitHub Repo: fdehau/tui-rs
// Commit: fafad6c
// File: src/layout.rs


}
 }
 
/// A simple rectangle used in the computation of the layout and to give widgets an hint about the
 /// area they are supposed to render to.
 #[derive(Debug, Clone, Copy, Hash, PartialEq, Eq, Default)]
 pub struct Rect {