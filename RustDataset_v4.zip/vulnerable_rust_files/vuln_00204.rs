// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2021-0068
// CVE: CVE-2021-38188
// CWE: N/A
// Crate: iced-x86
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/iced-x86
// Extraction Method: repo_search
// GitHub Repo: icedland/iced
// Commit: 54c233b
// File: src/rust/iced-x86-py/src/lib.rs


#![warn(clippy::dbg_macro)]
 #![warn(clippy::debug_assert_with_mut_call)]
 #![warn(clippy::default_trait_access)]
#![warn(clippy::doc_markdown)]
 #![warn(clippy::empty_line_after_outer_attr)]
 #![warn(clippy::expect_used)]
 #![warn(clippy::explicit_into_iter_loop)]