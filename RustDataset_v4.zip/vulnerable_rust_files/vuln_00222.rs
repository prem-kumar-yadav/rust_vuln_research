// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2021-0092
// CVE: CVE-2021-45690
// CWE: N/A
// Crate: messagepack-rs
// Type: memory_safety
// Severity: medium
// Source: https://crates.io/crates/messagepack-rs
// Extraction Method: repo_search
// GitHub Repo: otake84/messagepack-rs
// Commit: b097742
// File: messagepack-rs-macros/src/lib.rs


extern crate proc_macro;
 
 use crate::proc_macro::TokenStream;
     };
     gen.into()
 }