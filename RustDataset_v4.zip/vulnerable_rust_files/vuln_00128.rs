// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2020-0116
// CVE: CVE-2020-36436
// CWE: N/A
// Crate: unicycle
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/unicycle
// Extraction Method: repo_search
// GitHub Repo: udoprog/unicycle
// Commit: b14e95d
// File: tests/benchmark_test.rs


})
         .await;
 
        println!("tick: {}", i);
     }
 }