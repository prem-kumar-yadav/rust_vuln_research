// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2019-0003
// CVE: CVE-2019-15544
// CWE: N/A
// Crate: protobuf
// Type: memory_safety
// Severity: medium
// Source: https://crates.io/crates/protobuf
// Extraction Method: repo_search
// GitHub Repo: stepancheg/rust-protobuf
// Commit: f06992f
// File: protobuf/src/coded_input_stream/mod.rs


}
 
     fn skip_group(&mut self) -> crate::Result<()> {
         while !self.eof()? {
             let wire_type = self.read_tag_unpack()?.1;
             if wire_type == WireType::EndGroup {
     /// Read message, do not check if message is initialized
     pub fn merge_message<M: Message>(&mut self, message: &mut M) -> crate::Result<()> {
         self.incr_recursion()?;
        struct DecrRecursion<'a, 'b>(&'a mut CodedInputStream<'b>);
        impl<'a, 'b> Drop for DecrRecursion<'a, 'b> {
            fn drop(&mut self) {
                self.0.decr_recursion();
            }
        }

        let mut decr = DecrRecursion(self);
 
        let len = decr.0.read_raw_varint64()?;
        let old_limit = decr.0.push_limit(len)?;
        message.merge_from(&mut decr.0)?;
        decr.0.pop_limit(old_limit);
         Ok(())
     }
 
         );
         assert_eq!("field 3", input.read_string().unwrap());
     }
 }