// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2018-0013
// CVE: CVE-2018-21000
// CWE: N/A
// Crate: safe-transmute
// Type: overflow
// Severity: medium
// Source: https://crates.io/crates/safe-transmute
// Extraction Method: crate_versions
// GitHub Repo: safe-transmute
// Commit: N/A
// File: lib.rs


//! This crate contains checked implementations of `transmute()`.
//!
//! The functions in this crate are not inherently safe, but just guarded against common simple mistakes
//! (like trying to create an 8-byte type from 7 bytes).
//!
//! Those functions are exactly as safe as the data passed to them - creating a null pointer,
//! for example, is not unsafe in and of itself, but dereferencing it certainly *is*,
//! but they don't do that (see [here](https://github.com/nabijaczleweli/safe-transmute-rs/issues/1)
//! for extended discussion).
//!
//! # Examples
//!
//! View bytes as a series of `u16`s:
//!
//! ```
//! # use safe_transmute::guarded_transmute_many;
//! # unsafe {
//! assert_eq!(guarded_transmute_many::<u16>(&[0x00, 0x01,
//!                                            0x12, 0x34,
//!                                            // Spare byte, unused
//!                                            0x00]).unwrap(),
//!            &[0x0100, 0x3412]);
//! # }
//! ```
//!
//! View all bytes as a series of `u16`s:
//!
//! ```
//! # use safe_transmute::guarded_transmute_many_pedantic;
//! # unsafe {
//! assert_eq!(guarded_transmute_many_pedantic::<u16>(&[0x00, 0x01,
//!                                                     0x12, 0x34]).unwrap(),
//!            &[0x0100, 0x3412]);
//! # }
//! ```
//!
//! View bytes as an `f64`:
//!
//! ```
//! # use safe_transmute::guarded_transmute;
//! # unsafe {
//! assert_eq!(guarded_transmute::<f64>(&[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]).unwrap(),
//!            0.0);
//! # }
//! ```


mod error;

use std::slice;
use std::mem::align_of;

pub use self::error::{ErrorReason, Error};


/// Transmute a byte slice into a single instance of a `Copy`able type
///
/// The byte slice must have at least enough bytes to fill a single instance of a type,
/// extraneous data is ignored.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute::<u32>(&[0x00, 0x00, 0x00, 0x01]).unwrap(), 0x01000000);
/// # }
/// ```
pub unsafe fn guarded_transmute<T: Copy>(bytes: &[u8]) -> Result<T, Error> {
    if bytes.len() < align_of::<T>() {
        Err(Error {
            required: align_of::<T>(),
            actual: bytes.len(),
            reason: ErrorReason::NotEnoughBytes,
        })
    } else {
        Ok(slice::from_raw_parts(bytes.as_ptr() as *const T, 1)[0])
    }
}

/// Transmute a byte slice into a single instance of a `Copy`able type
///
/// The byte slice must have exactly enough bytes to fill a single instance of a type.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_pedantic;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_pedantic::<u16>(&[0x0F, 0x0E]).unwrap(), 0x0E0F);
/// # }
/// ```
pub unsafe fn guarded_transmute_pedantic<T: Copy>(bytes: &[u8]) -> Result<T, Error> {
    if bytes.len() != align_of::<T>() {
        Err(Error {
            required: align_of::<T>(),
            actual: bytes.len(),
            reason: ErrorReason::InexactByteCount,
        })
    } else {
        Ok(slice::from_raw_parts(bytes.as_ptr() as *const T, 1)[0])
    }
}

/// View a byte slice as a slice of an arbitrary type.
///
/// The byte slice must have at least enough bytes to fill a single instance of a type,
/// extraneous data is ignored.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_many;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_many::<u16>(&[0x00, 0x01, 0x00, 0x02]).unwrap(), &[0x0100, 0x0200]);
/// # }
/// ```
pub unsafe fn guarded_transmute_many<T>(bytes: &[u8]) -> Result<&[T], Error> {
    if bytes.len() < align_of::<T>() {
        Err(Error {
            required: align_of::<T>(),
            actual: bytes.len(),
            reason: ErrorReason::NotEnoughBytes,
        })
    } else {
        Ok(guarded_transmute_many_permissive(bytes))
    }
}

/// View a byte slice as a slice of an arbitrary type.
///
/// The resulting slice will have as many instances of a type as will fit, rounded down.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_many_permissive;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_many_permissive::<u16>(&[0x00]), &[]);
/// # }
/// ```
pub unsafe fn guarded_transmute_many_permissive<T>(bytes: &[u8]) -> &[T] {
    slice::from_raw_parts(bytes.as_ptr() as *const T, (bytes.len() - (bytes.len() % align_of::<T>())) / align_of::<T>())
}

/// View a byte slice as a slice of an arbitrary type.
///
/// The byte slice must have at least enough bytes to fill a single instance of a type,
/// and should not have extraneous data.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_many_pedantic;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_many_pedantic::<u16>(&[0x0F, 0x0E, 0x0A, 0x0B]).unwrap(), &[0x0E0F, 0x0B0A]);
/// # }
/// ```
pub unsafe fn guarded_transmute_many_pedantic<T>(bytes: &[u8]) -> Result<&[T], Error> {
    if bytes.len() < align_of::<T>() {
        Err(Error {
            required: align_of::<T>(),
            actual: bytes.len(),
            reason: ErrorReason::NotEnoughBytes,
        })
    } else if bytes.len() % align_of::<T>() != 0 {
        Err(Error {
            required: align_of::<T>(),
            actual: bytes.len(),
            reason: ErrorReason::InexactByteCount,
        })
    } else {
        Ok(slice::from_raw_parts(bytes.as_ptr() as *const T, bytes.len() / align_of::<T>()))
    }
}

/// Trasform a byte vector into a vector of an arbitrary type.
///
/// The resulting vec will reuse the allocated byte buffer when possible, and 
/// should have at least enough bytes to fill a single instance of a type.
/// Extraneous data is ignored.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_vec;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_vec::<u16>(vec![0x00, 0x01, 0x00, 0x02]), Ok(vec![0x0100, 0x0200]));
/// assert_eq!(guarded_transmute_vec::<u32>(vec![0x04, 0x00, 0x00, 0x00, 0xED]), Ok(vec![4]));
/// assert!(guarded_transmute_vec::<i16>(vec![0xED]).is_err());
/// # }
/// ```
pub unsafe fn guarded_transmute_vec<T>(bytes: Vec<u8>) -> Result<Vec<T>, Error> {
    if bytes.len() < align_of::<T>() {
        Err(Error {
            required: align_of::<T>(),
            actual: bytes.len(),
            reason: ErrorReason::NotEnoughBytes,
        })
    } else {
        Ok(guarded_transmute_vec_permissive(bytes))
    }
}

/// Trasform a byte vector into a vector of an arbitrary type.
///
/// The vector's allocated byte buffer will be reused when possible, and 
/// have as many instances of a type as will fit, rounded down.
/// Extraneous data is ignored.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_vec_permissive;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_vec_permissive::<u16>(vec![0x00, 0x01, 0x00, 0x02]), vec![0x0100, 0x0200]);
/// assert_eq!(guarded_transmute_vec_permissive::<u32>(vec![0x04, 0x00, 0x00, 0x00, 0xED]), vec![4]);
/// assert_eq!(guarded_transmute_vec_permissive::<u16>(vec![0xED]), vec![]);
/// # }
/// ```
pub unsafe fn guarded_transmute_vec_permissive<T>(mut bytes: Vec<u8>) -> Vec<T> {
    let ptr = bytes.as_mut_ptr();
    let capacity = bytes.capacity() / align_of::<T>();
    let len = bytes.len() / align_of::<T>();
    ::std::mem::forget(bytes);
    Vec::from_raw_parts(ptr as *mut T, capacity, len)
}


/// Trasform a byte vector into a vector of an arbitrary type.
///
/// The vector's allocated byte buffer will be reused when possible, and
/// should not have extraneous data.
///
/// # Examples
///
/// ```
/// # use safe_transmute::guarded_transmute_vec_pedantic;
/// // Little-endian
/// # unsafe {
/// assert_eq!(guarded_transmute_vec_pedantic::<u16>(vec![0x00, 0x01, 0x00, 0x02]).unwrap(), vec![0x0100, 0x0200]);
/// assert!(guarded_transmute_vec_pedantic::<u32>(vec![0x04, 0x00, 0x00, 0x00, 0xED]).is_err());
/// # }
/// ```
pub unsafe fn guarded_transmute_vec_pedantic<T>(bytes: Vec<u8>) -> Result<Vec<T>, Error> {
    let a = align_of::<T>();
    let len = bytes.len();
    if len < a {
        Err(Error {
            required: a,
            actual: len,
            reason: ErrorReason::NotEnoughBytes,
        })
    } else if len % a != 0 {
        Err(Error {
            required: a,
            actual: len,
            reason: ErrorReason::InexactByteCount,
        })
    } else {
        Ok(guarded_transmute_vec_permissive(bytes))
    }
}
