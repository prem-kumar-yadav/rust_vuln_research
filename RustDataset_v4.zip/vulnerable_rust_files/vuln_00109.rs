// REAL VULNERABLE CODE
// RustSec ID: RUSTSEC-2020-0095
// CVE: N/A
// CWE: N/A
// Crate: difference
// Type: unknown
// Severity: medium
// Source: https://crates.io/crates/difference
// Extraction Method: repo_search
// GitHub Repo: johannhof/difference.rs
// Commit: 54bdfa2
// File: src/lib.rs


//! Functions to find the difference between two texts (strings).
 //! Usage
 //! ----------
 //!
 //! ```
 //!
 //! Now you can use the crate in your code
 //! ```ignore
 //! extern crate difference;
 //! ```